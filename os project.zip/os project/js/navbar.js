var tog=document.getElementById("dropdowntoggle");
tog.style.display="none";
function toggle(){
    if (tog.style.display=="none") tog.style.display="block";
    else tog.style.display="none";
}